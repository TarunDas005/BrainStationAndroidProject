package yellow5a5.sample.ShareDemo;

/**
 * Created by Yellow5A5 on 16/9/17.
 */
public interface IShare {
    void faceBookShareClick();
    void twitterShareClick();
    void googlePlusShareClick();
}
