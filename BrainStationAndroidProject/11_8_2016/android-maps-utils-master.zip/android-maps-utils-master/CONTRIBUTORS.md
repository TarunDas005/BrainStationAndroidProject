<!-- Sorted alphabetically. -->

* Chris Broadfoot, https://github.com/broady
* Colin Edwards, https://github.com/DDRBoxman
* Michael Evans, https://github.com/MichaelEvans
* Maciej Gorski, https://github.com/mg6maciej
* Claus Höfele, https://github.com/choefele
* Cyril Mottier, https://github.com/cyrilmottier
* Mihai Preda, https://github.com/preda
* Iris Uy, https://github.com/irisu
* Emma Yeap, https://github.com/microcat
* Stefanos Togoulidis, https://github.com/hypest
